# -*- coding: utf-8 -*-
import re

PADROES_DADOS_PESSOAIS = {
    "cpf": r"\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b",
    "telefone": r"\b(\(?\d{2}\)?\s?)?\d{4,5}-?\d{4}\b",
    "email": r"\b[\w.+-]+@[\w-]+\.[\w.]+\b",
    "cep": r"\b\d{5}-?\d{3}\b",
}
PADROES_INJECTION = [r"ignore (as )?instru[cç][oõ]es", r"mostre (o )?prompt", r"\[SISTEMA\]", r"nova regra", r"revele (as )?instru[cç][oõ]es"]
CANARIO = "CANARIO-INTERNO-NAO-DEVE-VAZAR"

def mascarar(texto):
    saida = texto
    for nome, pat in PADROES_DADOS_PESSOAIS.items():
        saida = re.sub(pat, f"[{nome.upper()} OCULTADO]", saida)
    return saida

def contem_dados_pessoais(texto):
    for nome, pat in PADROES_DADOS_PESSOAIS.items():
        if re.search(pat, texto): return nome
    return None

def contem_injection(texto):
    return any(re.search(p, texto, re.I) for p in PADROES_INJECTION)

def validar_entrada(texto):
    if not texto or not texto.strip(): return "vazio"
    if len(texto) > 1000: return "muito_longo"
    if re.fullmatch(r"[\W\d_]+", texto.strip()): return "sem_sentido"
    if contem_dados_pessoais(texto): return "dados_pessoais"
    if contem_injection(texto): return "injection"
    return "ok"
