# -*- coding: utf-8 -*-
import os, re
from dataclasses import dataclass

@dataclass
class Ficha:
    codigo: str
    titulo: str
    palavras_chave: list
    texto: str
    versao: str = "01/10/2026"

def _parse(caminho):
    with open(caminho, encoding="utf-8") as f: bruto = f.read()
    titulo, chaves, versao = "", [], "01/10/2026"
    for linha in bruto.splitlines():
        if linha.startswith("# ") and not titulo: titulo = linha[2:].strip()
        m = re.search(r"Palavras-chave:\*\*\s*(.+)", linha, re.I)
        if m: chaves = [p.strip().lower() for p in m.group(1).split(",") if p.strip()]
        m = re.search(r"vers[aã]o de (\d{2}/\d{2}/\d{4})", linha, re.I)
        if m: versao = m.group(1)
    codigo = os.path.basename(caminho).split("_")[0]
    return Ficha(codigo, titulo, chaves, bruto, versao)

def carregar_fichas(pasta=None):
    if pasta is None:
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        pasta = os.path.join(base, "fichas")
    return [_parse(os.path.join(pasta, n)) for n in sorted(os.listdir(pasta))
            if n.startswith("FC-") and n.endswith(".md")]
