# -*- coding: utf-8 -*-
from dataclasses import dataclass

@dataclass
class ResultadoBusca:
    fichas: list
    pontos: list

class Indice:
    def __init__(self, fichas): self.fichas = fichas
    def buscar(self, pergunta, minimo=1, topo=3):
        q = pergunta.lower(); pontuados = []
        for f in self.fichas:
            p = 0
            for k in f.palavras_chave:
                if k and k in q: p += 2 if len(k) <= 4 else 1
            if f.titulo.lower() in q: p += 2
            if p >= minimo: pontuados.append((f.codigo, p))
        pontuados.sort(key=lambda x: -x[1])
        escolhidas = pontuados[:topo]
        codigos = [c for c, _ in escolhidas]
        pontos = [p for _, p in escolhidas]
        return ResultadoBusca([f for f in self.fichas if f.codigo in codigos], pontos)
