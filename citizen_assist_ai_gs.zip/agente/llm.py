# -*- coding: utf-8 -*-
import os, time, requests

class ErroLLM(Exception):
    pass

class LLMGroq:
    URL = "https://api.groq.com/openai/v1/chat/completions"
    def __init__(self, modelo=None, temperatura=0.2, max_tokens=800):
        self.chave = os.getenv("GROQ_API_KEY", "").strip()
        self.modelo = modelo or os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")
        self.temperatura = temperatura
        self.max_tokens = max_tokens
    def gerar(self, sistema, usuario):
        if not self.chave:
            raise ErroLLM("GROQ_API_KEY nao configurada")
        corpo = {"model": self.modelo, "temperature": self.temperatura, "max_tokens": self.max_tokens,
                 "messages": [{"role": "system", "content": sistema}, {"role": "user", "content": usuario}]}
        for tentativa in range(5):
            r = requests.post(self.URL, json=corpo, timeout=120, headers={"Authorization": "Bearer " + self.chave})
            if r.status_code == 429 or r.status_code >= 500:
                time.sleep(min(2 ** tentativa * 2, 30)); continue
            if r.status_code != 200:
                raise ErroLLM("HTTP %d" % r.status_code)
            texto = (r.json()["choices"][0]["message"].get("content") or "").strip()
            if texto: return texto
            raise ErroLLM("resposta vazia")
        raise ErroLLM("limite de uso")
