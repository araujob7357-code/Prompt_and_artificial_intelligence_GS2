# Central do Cidadão de Aurora — documentos de referência

**AVISO: material didático fictício.** Os valores, prazos, locais e regras destas fichas foram inventados para o desafio *Citizen Assist AI*. Não use nada daqui como informação real sobre documentos pessoais.

Estas fichas são a **única fonte de verdade** do assistente. Versão: 01/10/2026.
