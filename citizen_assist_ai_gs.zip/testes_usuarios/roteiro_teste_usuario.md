# Roteiro de teste com usuários

3 tarefas, tempos e acerto; 5 perguntas de facilidade (1 a 5). Sem nomes.
