# -*- coding: utf-8 -*-
import csv
def ler():
    with open("testes_usuarios/resultados_usuarios.csv", encoding="utf-8") as f:
        return list(csv.DictReader(f))
def calcular(linhas):
    if not linhas: raise ValueError("CSV vazio")
    tarefas = {"t1": {"nome": "Tarefa 1"}, "t2": {"nome": "Tarefa 2"}, "t3": {"nome": "Tarefa 3"}}
    for t in tarefas:
        tempos = [float(l[f"{t}_segundos"]) for l in linhas]
        acertos = [int(l[f"{t}_acertou"]) for l in linhas]
        tarefas[t]["tempo_medio_s"] = round(sum(tempos)/len(tempos), 1)
        tarefas[t]["acerto_pct"] = round(100*sum(acertos)/len(acertos), 1)
    acerto_geral = sum(int(l[f"t{i}_acertou"]) for l in linhas for i in (1,2,3)) / (3*len(linhas)) * 100
    facilidade = [int(l[f"q{i}"]) for l in linhas for i in range(1,6)]
    return {"tarefas": tarefas, "acerto_geral_pct": round(acerto_geral, 1),
            "facilidade_media": round(sum(facilidade)/len(facilidade), 2)}
